import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Trash2, User, Image as ImageIcon, CheckCircle, X, ExternalLink, Edit, Eye } from 'lucide-react';

const PRIORITY_COLORS = {
    High: 'badge-high',
    Medium: 'badge-medium',
    Low: 'badge-low',
    Critical: 'badge-critical'
};

const STATUS_OPTS = ['Open', 'In Progress', 'Closed'];

export default function BugList() {
    const [bugs, setBugs] = useState([]);
    const [users, setUsers] = useState([]);
    const [projects, setProjects] = useState([]);
    const [filterProject, setFilterProject] = useState('');

    const [showModal, setShowModal] = useState(false);
    const [loading, setLoading] = useState(false);
    const [screenshotFile, setScreenshotFile] = useState(null);
    const [editingId, setEditingId] = useState(null);
    const [viewBug, setViewBug] = useState(null);
    const [zoomedImage, setZoomedImage] = useState(null);

    const [formData, setFormData] = useState({
        title: '',
        description: '',
        priority: 'Medium',
        severity: 'Minor',
        assignee_id: '',
        reporter_id: 1,
        project_id: '',
        module: '',
        environment: '',
        steps_to_reproduce: '',
        expected_result: '',
        actual_result: ''
    });

    const fetchData = async () => {
        try {
            // Fetch Users
            const { data: usersData } = await supabase.from('users').select('*');
            setUsers(usersData || []);

            // Fetch Projects
            const { data: projectsData } = await supabase.from('projects').select('*');
            setProjects(projectsData || []);

            // Fetch Bugs with Joins
            let query = supabase
                .from('bugs')
                .select(`
                    *,
                    assignee:users!assignee_id(name, avatar),
                    project:projects!project_id(key, name)
                `)
                .order('created_at', { ascending: false });

            if (filterProject) {
                query = query.eq('project_id', filterProject);
            }

            const { data: bugsData, error } = await query;

            if (error) throw error;

            // Transform for compatibility with existing render logic
            const formattedBugs = bugsData.map(b => ({
                ...b,
                assignee_name: b.assignee?.name,
                assignee_avatar: b.assignee?.avatar,
                project_key: b.project?.key,
                project_name: b.project?.name
            }));
            setBugs(formattedBugs);
        } catch (err) {
            console.error('Error fetching data:', err);
        }
    };

    useEffect(() => {
        fetchData();
    }, [filterProject]);

    const handleFileChange = (e) => {
        setScreenshotFile(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            let screenshotUrl = '';

            // Upload image first if exists
            if (screenshotFile) {
                const fileExt = screenshotFile.name.split('.').pop();
                const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
                const { error: uploadError } = await supabase.storage
                    .from('screenshots')
                    .upload(fileName, screenshotFile);

                if (uploadError) throw uploadError;

                const { data: publicUrlData } = supabase.storage
                    .from('screenshots')
                    .getPublicUrl(fileName);

                screenshotUrl = publicUrlData.publicUrl;
            }

            const payload = { ...formData };
            // Ensure IDs are numbers or null
            if (!payload.assignee_id) payload.assignee_id = null;
            if (!payload.project_id) payload.project_id = null;

            if (screenshotUrl) payload.screenshot = screenshotUrl;

            if (editingId) {
                const { error } = await supabase
                    .from('bugs')
                    .update(payload)
                    .eq('id', editingId);
                if (error) throw error;
            } else {
                const { error } = await supabase
                    .from('bugs')
                    .insert([payload]);
                if (error) throw error;
            }

            setShowModal(false);
            resetForm();
            fetchData();
        } catch (err) {
            console.error('Error saving bug:', err);
            alert('Error saving bug: ' + err.message);
        } finally {
            setLoading(false);
        }
    };

    const resetForm = () => {
        setFormData({
            title: '', description: '', priority: 'Medium', severity: 'Minor', assignee_id: '', reporter_id: 1,
            project_id: '', module: '', environment: '', steps_to_reproduce: '', expected_result: '', actual_result: ''
        });
        setScreenshotFile(null);
        setEditingId(null);
    };

    const handleDelete = async (id) => {
        if (!confirm('Are you sure you want to delete this issue?')) return;
        try {
            const { error } = await supabase.from('bugs').delete().eq('id', id);
            if (error) throw error;
            setBugs(bugs.filter(b => b.id !== id));
        } catch (err) {
            console.error(err);
            alert('Error deleting bug');
        }
    };

    const handleStatusChange = async (id, newStatus) => {
        // Optimistic update
        setBugs(bugs.map(b => b.id === id ? { ...b, status: newStatus } : b));
        try {
            const { error } = await supabase.from('bugs').update({ status: newStatus }).eq('id', id);
            if (error) throw error;
        } catch (err) {
            console.error(err);
            fetchData(); // Revert on error
            alert('Error updating status');
        }
    };

    const handleEdit = (bug) => {
        setEditingId(bug.id);
        setFormData({
            title: bug.title,
            description: bug.description || '',
            priority: bug.priority,
            severity: bug.severity || 'Minor',
            assignee_id: bug.assignee_id || '',
            reporter_id: bug.reporter_id || 1,
            project_id: bug.project_id || '',
            module: bug.module || '',
            environment: bug.environment || '',
            steps_to_reproduce: bug.steps_to_reproduce || '',
            expected_result: bug.expected_result || '',
            actual_result: bug.actual_result || ''
        });
        setShowModal(true);
    };

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <div>
                    <h1 style={{ marginBottom: '0.5rem' }}>Issues</h1>
                    <p style={{ color: 'var(--text-muted)', margin: 0 }}>Track and manage software defects.</p>
                </div>
                <div style={{ display: 'flex', gap: '1rem' }}>
                    <select style={{ width: '200px' }} value={filterProject} onChange={e => setFilterProject(e.target.value)}>
                        <option value="">All Projects</option>
                        {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                    <button className="btn btn-primary" onClick={() => { resetForm(); setShowModal(true); }}>
                        <Plus size={18} /> New Issue
                    </button>
                </div>
            </div>

            {showModal && (
                <div style={{
                    position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    zIndex: 100, backdropFilter: 'blur(4px)'
                }} onClick={(e) => { if (e.target === e.currentTarget) setShowModal(false); }}>
                    <div className="glass card" style={{ width: '800px', maxWidth: '95%', background: '#1e293b', maxHeight: '90vh', overflowY: 'auto' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
                            <h2 style={{ margin: 0 }}>{editingId ? 'Edit Issue' : 'Report Bug'}</h2>
                            <button className="btn" onClick={() => setShowModal(false)}><X size={20} /></button>
                        </div>
                        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1rem' }}>
                                <div>
                                    <label>Title</label>
                                    <input required value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} placeholder="e.g. Login button not working" />
                                </div>
                                <div>
                                    <label>Project</label>
                                    <select required value={formData.project_id} onChange={e => setFormData({ ...formData, project_id: e.target.value })}>
                                        <option value="">Select Project...</option>
                                        {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label>Module</label>
                                    <input value={formData.module} onChange={e => setFormData({ ...formData, module: e.target.value })} placeholder="e.g. Auth, Checkout..." />
                                </div>
                            </div>

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
                                <div>
                                    <label>Priority</label>
                                    <select value={formData.priority} onChange={e => setFormData({ ...formData, priority: e.target.value })}>
                                        <option>Low</option>
                                        <option>Medium</option>
                                        <option>High</option>
                                        <option>Critical</option>
                                    </select>
                                </div>
                                <div>
                                    <label>Assignee</label>
                                    <select value={formData.assignee_id} onChange={e => setFormData({ ...formData, assignee_id: e.target.value })}>
                                        <option value="">Unassigned</option>
                                        {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label>Environment</label>
                                    <input value={formData.environment} onChange={e => setFormData({ ...formData, environment: e.target.value })} placeholder="e.g. Chrome, iOS..." />
                                </div>
                            </div>

                            <div>
                                <label>Description</label>
                                <textarea rows={2} value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} placeholder="Brief summary..." />
                            </div>

                            <div>
                                <label>Steps to Reproduce</label>
                                <textarea rows={3} value={formData.steps_to_reproduce} onChange={e => setFormData({ ...formData, steps_to_reproduce: e.target.value })} placeholder="1. Go to homepage&#10;2. Click on..." />
                            </div>

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                                <div>
                                    <label>Expected Result</label>
                                    <textarea rows={2} value={formData.expected_result} onChange={e => setFormData({ ...formData, expected_result: e.target.value })} />
                                </div>
                                <div>
                                    <label>Actual Result</label>
                                    <textarea rows={2} value={formData.actual_result} onChange={e => setFormData({ ...formData, actual_result: e.target.value })} />
                                </div>
                            </div>

                            <div>
                                <label>Screenshot (Browse or Paste Ctrl+V)</label>
                                <div
                                    tabIndex={0}
                                    onPaste={(e) => {
                                        const items = e.clipboardData.items;
                                        for (const item of items) {
                                            if (item.type.indexOf('image') !== -1) {
                                                const blob = item.getAsFile();
                                                setScreenshotFile(blob);
                                                e.preventDefault();
                                            }
                                        }
                                    }}
                                    style={{
                                        border: '2px dashed var(--border-color)',
                                        padding: '2rem',
                                        borderRadius: '0.5rem',
                                        textAlign: 'center',
                                        // cursor: 'pointer', // Removed to avoid confusion
                                        background: screenshotFile ? 'rgba(16, 185, 129, 0.1)' : 'transparent',
                                        borderColor: screenshotFile ? '#10b981' : 'var(--border-color)',
                                        transition: 'all 0.2s',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        gap: '0.5rem',
                                        outline: 'none' // We can add a focus style globally or inline if needed
                                    }}
                                // onClick handler removed from here
                                >
                                    <input
                                        id="fileInput"
                                        type="file"
                                        accept="image/*"
                                        onChange={handleFileChange}
                                        style={{ display: 'none' }}
                                    />
                                    {screenshotFile ? (
                                        <>
                                            <CheckCircle size={32} color="#10b981" />
                                            <span style={{ color: '#10b981', fontWeight: 500 }}>Image ready to upload!</span>
                                            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{screenshotFile.name || 'Pasted Image.png'}</span>
                                            <button
                                                type="button"
                                                className="btn"
                                                style={{ fontSize: '0.8rem', padding: '0.2rem 0.5rem', marginTop: '0.5rem' }}
                                                onClick={(e) => { e.stopPropagation(); setScreenshotFile(null); }}
                                            >
                                                Clear
                                            </button>
                                        </>
                                    ) : (
                                        <>
                                            <ImageIcon size={32} color="var(--text-muted)" />
                                            <span style={{ color: 'var(--text-muted)' }}>
                                                <button
                                                    type="button"
                                                    style={{
                                                        background: 'none',
                                                        border: 'none',
                                                        color: 'var(--primary)',
                                                        textDecoration: 'underline',
                                                        cursor: 'pointer',
                                                        fontWeight: 'bold',
                                                        padding: 0
                                                    }}
                                                    onClick={() => document.getElementById('fileInput').click()}
                                                >
                                                    Click to Browse
                                                </button>
                                                {' '}or <strong>Paste (Ctrl+V)</strong> here
                                            </span>
                                        </>
                                    )}
                                </div>
                            </div>

                            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '1rem', marginTop: '1rem' }}>
                                <button type="button" className="btn" onClick={() => setShowModal(false)}>Cancel</button>
                                <button type="submit" className="btn btn-primary" disabled={loading}>
                                    {loading ? 'Saving...' : (editingId ? 'Update Issue' : 'Create Issue')}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {viewBug && (
                <div style={{
                    position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    zIndex: 100, backdropFilter: 'blur(4px)'
                }} onClick={(e) => { if (e.target === e.currentTarget) setViewBug(null); }}>
                    <div className="glass card" style={{ width: '800px', maxWidth: '95%', background: '#1e293b', maxHeight: '90vh', overflowY: 'auto', position: 'relative' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.5rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '1rem' }}>
                            <div>
                                <h2 style={{ margin: 0, fontSize: '1.5rem' }}>{viewBug.title}</h2>
                                <div style={{ fontSize: '0.9rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>
                                    #{viewBug.id} • {viewBug.project_name || 'No Project'} • Reported by User #{viewBug.reporter_id}
                                </div>
                            </div>
                            <button className="btn" onClick={() => setViewBug(null)}><X size={20} /></button>
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                                <div>
                                    <h4 style={{ margin: '0 0 0.5rem 0', color: 'var(--text-muted)' }}>Description</h4>
                                    <p style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{viewBug.description || 'No description provided.'}</p>
                                </div>

                                <div>
                                    <h4 style={{ margin: '0 0 0.5rem 0', color: 'var(--text-muted)' }}>Steps to Reproduce</h4>
                                    <p style={{ whiteSpace: 'pre-wrap', margin: 0, background: 'rgba(0,0,0,0.2)', padding: '1rem', borderRadius: '0.5rem' }}>
                                        {viewBug.steps_to_reproduce || 'No steps provided.'}
                                    </p>
                                </div>

                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                                    <div>
                                        <h4 style={{ margin: '0 0 0.5rem 0', color: 'var(--text-muted)' }}>Expected Result</h4>
                                        <p style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{viewBug.expected_result || '-'}</p>
                                    </div>
                                    <div>
                                        <h4 style={{ margin: '0 0 0.5rem 0', color: 'var(--text-muted)' }}>Actual Result</h4>
                                        <p style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{viewBug.actual_result || '-'}</p>
                                    </div>
                                </div>

                                {viewBug.screenshot && (
                                    <div>
                                        <h4 style={{ margin: '0 0 0.5rem 0', color: 'var(--text-muted)' }}>Attachment</h4>
                                        <img
                                            src={viewBug.screenshot}
                                            alt="Attachment"
                                            style={{ maxWidth: '100%', borderRadius: '0.5rem', border: '1px solid var(--border-color)', cursor: 'zoom-in' }}
                                            onClick={() => setZoomedImage(viewBug.screenshot)}
                                        />
                                    </div>
                                )}
                            </div>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                                <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
                                    <div style={{ marginBottom: '1rem' }}>
                                        <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>Status</label>
                                        <span className="badge" style={{ background: 'var(--primary)', color: 'white' }}>{viewBug.status}</span>
                                    </div>
                                    <div style={{ marginBottom: '1rem' }}>
                                        <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>Priority</label>
                                        <span className={`badge ${PRIORITY_COLORS[viewBug.priority] || 'badge-low'}`}>{viewBug.priority}</span>
                                    </div>
                                    <div style={{ marginBottom: '1rem' }}>
                                        <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>Severity</label>
                                        <span>{viewBug.severity || 'Minor'}</span>
                                    </div>
                                    <div style={{ marginBottom: '1rem' }}>
                                        <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>Assignee</label>
                                        {viewBug.assignee_name ? (
                                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                                <img src={viewBug.assignee_avatar} alt="" className="avatar" />
                                                <span>{viewBug.assignee_name}</span>
                                            </div>
                                        ) : <span style={{ color: 'var(--text-muted)' }}>Unassigned</span>}
                                    </div>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>Environment</label>
                                        <span>{viewBug.environment || 'Not specified'}</span>
                                    </div>
                                    <div style={{ marginTop: '1rem' }}>
                                        <label style={{ display: 'block', fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>Module</label>
                                        <span>{viewBug.module || 'General'}</span>
                                    </div>
                                </div>

                                <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => { handleEdit(viewBug); setViewBug(null); }}>
                                    <Edit size={16} /> Edit Issue
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <div className="glass card table-container">
                <table>
                    <thead>
                        <tr>
                            <th style={{ width: '60px' }}>#ID</th>
                            <th>Title / Project</th>
                            <th style={{ width: '150px' }}>Status</th>
                            <th style={{ width: '120px' }}>Priority</th>
                            <th>Assignee</th>
                            <th>Attachment</th>
                            <th style={{ width: '180px' }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {bugs.map(bug => (
                            <tr key={bug.id}>
                                <td style={{ color: 'var(--text-muted)' }}>#{bug.id}</td>
                                <td>
                                    <div style={{ fontWeight: 500 }}>{bug.title}</div>
                                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                                        {bug.project_key ? <span style={{ color: 'var(--primary)', fontWeight: 'bold' }}>{bug.project_key}</span> : 'No Project'}
                                        {' • '}{bug.created_at?.split('T')[0]}
                                    </div>
                                </td>
                                <td>
                                    <select
                                        value={bug.status}
                                        onChange={(e) => handleStatusChange(bug.id, e.target.value)}
                                        style={{ padding: '0.25rem', fontSize: '0.85rem', width: 'auto' }}
                                    >
                                        {STATUS_OPTS.map(s => <option key={s}>{s}</option>)}
                                    </select>
                                </td>
                                <td>
                                    <span className={`badge ${PRIORITY_COLORS[bug.priority] || 'badge-low'}`}>
                                        {bug.priority}
                                    </span>
                                </td>
                                <td>
                                    {bug.assignee_name ? (
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                            <img src={bug.assignee_avatar} alt="" className="avatar" />
                                            <span style={{ fontSize: '0.9rem' }}>{bug.assignee_name}</span>
                                        </div>
                                    ) : (
                                        <span style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>Unassigned</span>
                                    )}
                                </td>
                                <td>
                                    {bug.screenshot && (
                                        <a href={bug.screenshot} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.9rem' }}>
                                            <ImageIcon size={16} /> View
                                        </a>
                                    )}
                                </td>
                                <td>
                                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                                        <button className="btn" style={{ padding: '0.25rem 0.5rem' }} onClick={() => setViewBug(bug)} title="View Details">
                                            <Eye size={16} />
                                        </button>
                                        <button className="btn" style={{ padding: '0.25rem 0.5rem' }} onClick={() => handleEdit(bug)} title="Edit">
                                            <Edit size={16} />
                                        </button>
                                        <button className="btn btn-danger" style={{ padding: '0.25rem 0.5rem' }} onClick={() => handleDelete(bug.id)}>
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        {bugs.length === 0 && (
                            <tr>
                                <td colSpan={7} style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
                                    No bugs found.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>


            {
                zoomedImage && (
                    <div
                        style={{
                            position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(0,0,0,0.9)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'zoom-out'
                        }}
                        onClick={() => setZoomedImage(null)}
                    >
                        <img
                            src={zoomedImage}
                            alt="Full Screen"
                            style={{ maxWidth: '95vw', maxHeight: '95vh', objectFit: 'contain', boxShadow: '0 0 20px rgba(0,0,0,0.5)' }}
                        />
                        <button
                            style={{
                                position: 'absolute', top: '2rem', right: '2rem', background: 'white', color: 'black',
                                border: 'none', borderRadius: '50%', width: '40px', height: '40px', display: 'flex',
                                alignItems: 'center', justifyContent: 'center', cursor: 'pointer'
                            }}
                        >
                            <X size={24} />
                        </button>
                    </div>
                )
            }
        </div >
    )
}
