import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { AlertCircle, CheckCircle, Clock, Activity } from 'lucide-react';

export default function Dashboard() {
    const [stats, setStats] = useState({ total: 0, open: 0, closed: 0, inProgress: 0 });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        axios.get('/api/stats')
            .then(res => setStats(res.data))
            .catch(err => console.error(err))
            .finally(() => setLoading(false));
    }, []);

    const StatCard = ({ title, value, icon: Icon, color }) => (
        <div className="glass card" style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ padding: '1rem', borderRadius: '12px', background: `${color}20`, color: color }}>
                <Icon size={24} />
            </div>
            <div>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginBottom: '0.25rem' }}>{title}</div>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', lineHeight: 1 }}>{loading ? '-' : value}</div>
            </div>
        </div>
    );

    return (
        <div>
            <h1 style={{ marginBottom: '2rem', fontSize: '2rem' }}>Dashboard Overview</h1>

            <div className="stat-grid">
                <StatCard title="Total Bugs" value={stats.total} icon={Activity} color="#6366f1" />
                <StatCard title="Open Issues" value={stats.open} icon={AlertCircle} color="#ef4444" />
                <StatCard title="In Progress" value={stats.inProgress} icon={Clock} color="#f59e0b" />
                <StatCard title="Resolved" value={stats.closed} icon={CheckCircle} color="#10b981" />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem' }}>
                <div className="glass card">
                    <h3 style={{ marginTop: 0 }}>System Health</h3>
                    <div style={{ height: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', background: 'rgba(0,0,0,0.2)', borderRadius: '8px' }}>
                        Chart Visualization Area
                    </div>
                </div>
                <div className="glass card">
                    <h3 style={{ marginTop: 0 }}>Quick Actions</h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>+ Report New Bug</button>
                        <button className="btn" style={{ width: '100%', justifyContent: 'center', background: 'rgba(255,255,255,0.05)' }}>View Documentation</button>
                    </div>
                </div>
            </div>
        </div>
    );
}
